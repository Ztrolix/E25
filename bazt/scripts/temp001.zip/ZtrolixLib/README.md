﻿# Hello developer!
This is version 0.1.0 of ZtrolixLib.


## 🏗 What's Coming Soon?
- **AI:** In the next update we will introduce AI.

### 🚀 Upgrade to Pro
[Upgrade your account](https://www.patreon.com/ztrolix) to boost your space and take your projects to the next level.